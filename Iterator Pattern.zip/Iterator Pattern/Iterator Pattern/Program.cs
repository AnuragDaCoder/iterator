﻿

using Iterator_Pattern;

EmployeeCollection emp = new EmployeeCollection();
emp.Add(new Employee(1, "Anurag", "Nayak"));
emp.Add(new Employee(2, "Abhishek", "Nayak"));
emp.Add(new Employee(3, "Shalin", "Bhanot"));
emp.Add(new Employee(4, "Manish", "Singh"));

var employeeIterator = emp.CreateIterator();

for (Employee employee = employeeIterator.First(); !employeeIterator.IsDone;
    employee = employeeIterator.Next())
{
    Console.WriteLine(employee?.FirstName + " " + employee?.LastName);
}