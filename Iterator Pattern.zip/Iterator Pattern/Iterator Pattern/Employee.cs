﻿
namespace Iterator_Pattern
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public Employee(int employeeId, string firstName, string lastName)
        {
            EmployeeId = employeeId;
            FirstName = firstName;
            LastName = lastName;
        }
    }

    public interface IEmployeeIterator
    {
        Employee First();
        Employee Next();
        bool IsDone { get; }
        Employee CurrentItem { get; }
    }

    public interface IEmployeeCollection
    {
        IEmployeeIterator CreateIterator();
    }

    public class EmployeeCollection : List<Employee>, IEmployeeCollection
    {
        public IEmployeeIterator CreateIterator()
        {
            return new EmployeeIterator(this);
        }
    }

    public class EmployeeIterator : IEmployeeIterator
    {

        private EmployeeCollection _employeeCollection;
        private int _current = 0;
        public EmployeeIterator(EmployeeCollection employeeCollection)
        {
            _employeeCollection = employeeCollection;
        }

        public bool IsDone => _current >= _employeeCollection.Count;

        public Employee CurrentItem => _employeeCollection.OrderBy(e => e.EmployeeId).ToList()[_current];

        public Employee First()
        {
            _current = 0;
            return _employeeCollection.OrderBy(e => e.EmployeeId).ToList()[_current];
        }

        public Employee Next()
        {
            _current++;

            if (!IsDone)
            {
                return _employeeCollection.OrderBy(e => e.EmployeeId).ToList()[_current];

            }
            else
            {
                return null;
            }
        }
    }
}
